from prometheus_client import start_http_server, Gauge
import os
import psutil
import time

# Create a metric to track memory usage
process = psutil.Process(os.getpid())
memory_gauge = Gauge('python_process_memory_bytes', 'Resident memory used by the Python process in bytes')

def collect_memory_usage():
    memory_gauge.set(process.memory_info().rss)  # RSS: Resident Set Size

if __name__ == "__main__":
    start_http_server(8000)  # Prometheus will scrape this port
    print("Prometheus metrics available at http://localhost:8000/metrics")
    while True:
        collect_memory_usage()
        time.sleep(5)
